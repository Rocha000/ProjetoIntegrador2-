module.exports = {
    user: "ebd1es82286",
    password: "Orntf2",
    connectString:"(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=172.16.12.48)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SID=xe)))"
  };